﻿namespace SecretariaConcafras.Application.DTOs.Participantes
{
    public class ParticipanteUpdateDto : ParticipanteCreateDto
    {
        public Guid Id { get; set; }
    }
}
