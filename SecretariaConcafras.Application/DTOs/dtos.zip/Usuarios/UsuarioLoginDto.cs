﻿namespace SecretariaConcafras.Application.DTOs.Usuarios
{
    public class UsuarioLoginDto
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
