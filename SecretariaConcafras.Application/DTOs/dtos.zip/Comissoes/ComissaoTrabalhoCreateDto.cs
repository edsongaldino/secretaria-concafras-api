﻿namespace SecretariaConcafras.Application.DTOs.Comissoes
{
    public class ComissaoTrabalhoCreateDto
    {
        public string Nome { get; set; }
        public Guid EventoId { get; set; }
    }
}
