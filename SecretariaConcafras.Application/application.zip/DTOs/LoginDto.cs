namespace SecretariaConcafras.Application.DTOs;

public class LoginDto
{
    public string Email { get; set; }
    public string Senha { get; set; }
}
