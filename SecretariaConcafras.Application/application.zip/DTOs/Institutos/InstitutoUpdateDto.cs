﻿namespace SecretariaConcafras.Application.DTOs.Institutos
{
    public class InstitutoUpdateDto
    {
        public string Nome { get; set; }
    }
}
