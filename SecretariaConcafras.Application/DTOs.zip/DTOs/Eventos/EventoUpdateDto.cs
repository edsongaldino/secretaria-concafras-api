﻿namespace SecretariaConcafras.Application.DTOs.Eventos
{
    public class EventoUpdateDto : EventoCreateDto
    {
        public Guid Id { get; set; }
    }
}
