﻿namespace SecretariaConcafras.Application.DTOs.Cidades
{
    public class CidadeResponseDto
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public Guid EstadoId { get; set; }
    }
}
