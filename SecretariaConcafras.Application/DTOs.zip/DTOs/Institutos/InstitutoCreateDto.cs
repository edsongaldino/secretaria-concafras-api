﻿namespace SecretariaConcafras.Application.DTOs.Institutos
{
    public class InstitutoCreateDto
    {
        public string Nome { get; set; }
    }
}
