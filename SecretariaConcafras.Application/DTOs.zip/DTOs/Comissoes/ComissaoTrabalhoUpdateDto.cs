﻿namespace SecretariaConcafras.Application.DTOs.Comissoes
{
    public class ComissaoTrabalhoUpdateDto : ComissaoTrabalhoCreateDto
    {
        public Guid Id { get; set; }
    }
}
