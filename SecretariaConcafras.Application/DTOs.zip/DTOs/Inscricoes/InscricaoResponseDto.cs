﻿using SecretariaConcafras.Application.DTOs.Cursos;
using SecretariaConcafras.Domain.Enums;

namespace SecretariaConcafras.Application.DTOs.Inscricoes
{
    public class InscricaoResponseDto
    {
        public Guid Id { get; set; }
        public string ParticipanteNome { get; set; }
        public string EventoTitulo { get; set; }

        public bool EhTrabalhador { get; set; }

        // Cursos vinculados à inscrição (pode ser 0, 1 ou 2 cursos)
        public List<CursoResponseDto> Cursos { get; set; } = new();

        // Caso seja trabalhador
        public string? ComissaoNome { get; set; }

        // Último check-in feito
        public TipoCheckin? UltimoCheckin { get; set; }

        public DateTime DataInscricao { get; set; }
    }
}
